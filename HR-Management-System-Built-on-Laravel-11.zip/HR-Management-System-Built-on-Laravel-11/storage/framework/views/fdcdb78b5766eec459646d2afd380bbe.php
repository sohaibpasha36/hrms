
<?php $__env->startSection('content'); ?>
    
    
    <!-- Page Wrapper -->
    <div class="page-wrapper">
        <!-- Page Content -->
        <div class="content container-fluid">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <!-- Page Header -->
                    <div class="page-header">
                        <div class="row">
                            <div class="col-sm-12">
                                <h3 class="page-title">Company Settings</h3>
                            </div>
                        </div>
                    </div>
                    <!-- /Page Header -->
                    <form action="<?php echo e(route('company/settings/save')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" class="form-control" name="id" value="1">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Company Name <span class="text-danger">*</span></label>
                                    <?php if(!empty($companySettings->company_name)): ?>
                                    <input class="form-control" type="text" name="company_name" value="<?php echo e($companySettings->company_name); ?>">
                                    <?php else: ?>
                                    <input class="form-control" type="text" name="company_name" value="">
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Contact Person</label>
                                    <?php if(!empty($companySettings->contact_person)): ?>
                                    <input type="text" class="form-control" name="contact_person" value="<?php echo e($companySettings->contact_person); ?>">
                                    <?php else: ?>
                                    <input type="text" class="form-control" name="contact_person" value="">
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label>Address</label>
                                    <?php if(!empty($companySettings->address)): ?>
                                    <input type="text" class="form-control" name="address" value="<?php echo e($companySettings->address); ?>">
                                    <?php else: ?>
                                    <input type="text" class="form-control" name="address" value="">

                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-6 col-lg-3">
                                <div class="form-group">
                                    <label>Country</label>
                                    <select class="form-control select" name="country">
                                        <?php if(!empty($companySettings->country)): ?>
                                            <option value="KHMER" <?php echo e(( $companySettings->country == 'KHMER') ? 'selected' : ''); ?>> KHMER</option>
                                            <option value="USA" <?php echo e(( $companySettings->country == 'USA') ? 'selected' : ''); ?>> USA</option>
                                            <option value="United Kingdom" <?php echo e(( $companySettings->country == 'United Kingdom') ? 'selected' : ''); ?>> United Kingdom</option> 
                                        <?php else: ?>
                                            <option value="KHMER">KHMER</option>
                                            <option value="USA">USA</option>
                                            <option value="United Kingdom">United Kingdom</option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-6 col-lg-3">
                                <div class="form-group">
                                    <label>City</label>
                                    <?php if(!empty($companySettings->city)): ?>
                                        <input type="text" class="form-control" name="city" value="<?php echo e($companySettings->city); ?>">
                                    <?php else: ?>
                                        <input type="text" class="form-control" name="city">
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-6 col-lg-3">
                                <div class="form-group">
                                    <label>State/Province</label>
                                    <select class="form-control select" name="state_province">
                                        <?php if(!empty($companySettings->state_province)): ?>
                                            <option value="Phnom Penh" <?php echo e(( $companySettings->state_province == 'Phnom Penh') ? 'selected' : ''); ?>> Phnom Penh</option>
                                            <option value="Pursat" <?php echo e(( $companySettings->state_province == 'Pursat') ? 'selected' : ''); ?>> Pursat</option>
                                            <option value="Kan dal" <?php echo e(( $companySettings->state_province == 'Kan dal') ? 'selected' : ''); ?>> Kan dal</option>
                                            <option value="Ta Keav" <?php echo e(( $companySettings->state_province == 'Ta Keav') ? 'selected' : ''); ?>> Ta Keav</option>
                                        <?php else: ?>
                                            <option value="Phnom Penh">Phnom Penh</option>
                                            <option value="Pursat">Pursat</option>
                                            <option value="Kan dal">Kan dal</option>
                                            <option value="Ta Keav">Ta Keav</option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-6 col-lg-3">
                                <div class="form-group">
                                    <label>Postal Code</label>
                                    <?php if(!empty($companySettings->postal_code)): ?>
                                        <input type="text" class="form-control" name="postal_code" value="<?php echo e($companySettings->postal_code); ?>">
                                    <?php else: ?>
                                        <input type="text" class="form-control" name="postal_code">
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Email</label>
                                    <?php if(!empty($companySettings->email)): ?>
                                        <input type="email" class="form-control" name="email" value="<?php echo e($companySettings->email); ?>">
                                    <?php else: ?>
                                        <input type="email" class="form-control" name="email">
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Phone Number</label>
                                    <?php if(!empty($companySettings->phone_number)): ?>
                                        <input type="tel" class="form-control" name="phone_number" value="<?php echo e($companySettings->phone_number); ?>">
                                    <?php else: ?>
                                        <input type="tel" class="form-control" name="phone_number">
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Mobile Number</label>
                                    <?php if(!empty($companySettings->mobile_number)): ?>
                                    <input type="tel" class="form-control" name="mobile_number" value="<?php echo e($companySettings->mobile_number); ?>">
                                    <?php else: ?>
                                    <input type="tel" class="form-control" name="mobile_number" value="">
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Fax</label>
                                    <?php if(!empty($companySettings->fax)): ?>
                                    <input type="text" class="form-control" name="fax" value="<?php echo e($companySettings->fax); ?>">
                                    <?php else: ?>
                                    <input type="text" class="form-control" name="fax" value="">
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label>Website Url</label>
                                    <?php if(!empty($companySettings->website_url)): ?>
                                    <input type="text" class="form-control" name="website_url" value="<?php echo e($companySettings->website_url); ?>">
                                    <?php else: ?>
                                    <input type="text" class="form-control" name="website_url" value="">
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="submit-section">
                            <button type="submit" class="btn btn-primary submit-btn">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- /Page Content -->
    </div>
    <!-- /Page Wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.settings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sohai\Downloads\HR\HR-Management-System-Built-on-Laravel-11\resources\views/settings/companysettings.blade.php ENDPATH**/ ?>